﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using UVVkedin.controle;
using UVVkedin.model;
using UVVkedin.BD;

namespace UVVkedin
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Amigo> ListaAmigos { get; set; }

        private AmigoControle Controler = new();

        public MainWindow()
        {
            InitializeComponent();
            ListaAmigos = [];
            DataContext = this;
        }

        private void CadastrarAmigo(object sender, RoutedEventArgs e)
        {
            if (!String.IsNullOrEmpty(apelidoTxtBox.Text) &&
                !String.IsNullOrEmpty(telefoneTxtBox.Text) &&
                !String.IsNullOrEmpty(emailTxtBox.Text))
            {
                if (Controler.CadastrarAmigoModel(apelidoTxtBox.Text, telefoneTxtBox.Text, emailTxtBox.Text))
                {
                    MessageBox.Show("Amigo cadastrado com sucesso");

                }
                else
                {
                    MessageBox.Show("Não foi possivel cadastrar o amigo");
                }
            }
        }

        private void BuscarAmigo(object sender, RoutedEventArgs e)
        {
            if (apelidoTxtBox.Text == "" && telefoneTxtBox.Text == "" && emailTxtBox.Text == "")
            {
                MessageBox.Show("Preencha o campo \"Apelido\"");
                return;
            }

            ListarAmigos_Click(sender, e);
            foreach (var item in ListaAmigos.ToList())
            {
                if (!item.nome.Contains(apelidoTxtBox.Text))
                {
                    ListaAmigos.Remove(item);
                }
            }
        }

        private void RemoverAmigo(object sender, RoutedEventArgs e)
        {
            BuscarAmigo(sender, e);
            if (ListaAmigos.Count == 0)
            {
                MessageBox.Show("Nenhum amigo encontrado");
                return;
            }

            if (MessageBox.Show($"Tem certeza que deseja remover o amigo \"{ListaAmigos[0].nome}\"?", "Remover amigo", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                Controler.RemoverAmigo(ListaAmigos[0]);
                ListaAmigos.RemoveAt(0);
                ListarAmigos_Click(sender, e);
            }
        }

        private void ListarAmigos_Click(object sender, RoutedEventArgs e)
        {
            ListaAmigos.Clear();
            foreach (var amigo in Controler.ListarAmigosModel())
            {
                ListaAmigos.Add(amigo);
            }
        }

    }
}