﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UVVkedin.model;

namespace UVVkedin.BD
{
    internal class BD
    {
        public static List<Amigo> myBD = [];
        public static ObservableCollection<Amigo> ListaAmigos { get; } = new();

        public static void SalvarAmigo(Amigo amigo) => ListaAmigos.Add(amigo);
        public static List<Amigo> RetornarBD() => myBD;

        public static void RemoverAmigo(Amigo amigo) => ListaAmigos.Remove(amigo);

    }
}
