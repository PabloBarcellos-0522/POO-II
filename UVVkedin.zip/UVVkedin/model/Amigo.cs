﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UVVkedin.BD;

namespace UVVkedin.model
{
    public class Amigo()
    {
        public string nome { get; set; }
        public string telefone { get; set; }
        public string email { get; set; } 

        public Boolean CadastrarAmigo(Amigo amigo)
        {
            BD.BD.SalvarAmigo(amigo);
            
            return true;
        }

        public ObservableCollection<Amigo> ListarAmigos()
        {
            return BD.BD.ListaAmigos;
        }

        public void RemoverAmigo(Amigo amigo)
        {
            BD.BD.RemoverAmigo(amigo);
        }
    }
}
