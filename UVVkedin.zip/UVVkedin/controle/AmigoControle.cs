﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UVVkedin.model;

namespace UVVkedin.controle
{
    internal class AmigoControle
    {
        private Amigo ModelAmigoControle = new();

        public Boolean CadastrarAmigoModel(string nome, string telefone, string email)
        {
            Amigo novoAmigo = new()
            {
                nome = nome,
                telefone = telefone,
                email = email
            };

            if (ModelAmigoControle.CadastrarAmigo(novoAmigo))
                return true;
            return false;
        }

        public ObservableCollection<Amigo> ListarAmigosModel()
        {
            return ModelAmigoControle.ListarAmigos();
        }

        public void RemoverAmigo(Amigo amigo)
        {
            ModelAmigoControle.RemoverAmigo(amigo);
        }
    }
}
